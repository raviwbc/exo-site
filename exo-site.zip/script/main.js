      let solutions = [
        {
          icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-map h-8 w-8 text-primary" aria-hidden="true"><path d="M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z"></path><path d="M15 5.764v15"></path><path d="M9 3.236v15"></path></svg>`,
          title: "Interactive Floor Maps",
          description:
            "Visualize floor layouts and choose seats with intuitive, interactive maps that provide real-time visibility of workspace availability.",
          features: [
            "Real-time seat visualization",
            "Interactive navigation",
            "Floor plan management",
          ],
        },
        {
          icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users h-8 w-8 text-primary" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><path d="M16 3.128a4 4 0 0 1 0 7.744"></path><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><circle cx="9" cy="7" r="4"></circle></svg>`,
          title: "Social Connectivity",
          description:
            "Make social connections and work near your colleagues. Add colleagues to your network to view their bookings and find nearby seats.",
          features: [
            "Colleague network",
            "Proximity seating",
            "Social booking recommendations",
          ],
        },
        {
          icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-qr-code h-8 w-8 text-primary" aria-hidden="true"><rect width="5" height="5" x="3" y="3" rx="1"></rect><rect width="5" height="5" x="16" y="3" rx="1"></rect><rect width="5" height="5" x="3" y="16" rx="1"></rect><path d="M21 16h-3a2 2 0 0 0-2 2v3"></path><path d="M21 21v.01"></path><path d="M12 7v3a2 2 0 0 1-2 2H7"></path><path d="M3 12h.01"></path><path d="M12 3h.01"></path><path d="M12 16v.01"></path><path d="M16 12h1"></path><path d="M21 12v.01"></path><path d="M12 21v-1"></path></svg>`,
          title: "QR Code Check-in/Out",
          description:
            "QR code-based check-in/out system to confirm occupancy and ensure accurate space utilization tracking.",
          features: [
            "Touchless verification",
            "Automated attendance",
            "Real-time occupancy tracking",
          ],
        },
        {
          icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-bell h-8 w-8 text-primary" aria-hidden="true"><path d="M10.268 21a2 2 0 0 0 3.464 0"></path><path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326"></path></svg>`,
          title: "Smart Notifications",
          description:
            "Reservation reminders and easy updates help you free up space for your colleagues and manage bookings efficiently.",
          features: [
            "Booking reminders",
            "Space release alerts",
            "Schedule management",
          ],
        },
        {
          icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-building2 lucide-building-2 h-8 w-8 text-primary" aria-hidden="true"><path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"></path><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"></path><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"></path><path d="M10 6h4"></path><path d="M10 10h4"></path><path d="M10 14h4"></path><path d="M10 18h4"></path></svg>`,
          title: "Employee Grade Allocation",
          description:
            "Employee grade-based seat allocation with various options including Workstations, Half Cabins, Full Cabins, and Executive Cabins.",
          features: [
            "Grade-based seating",
            "Multiple cabin types",
            "Executive workspace options",
          ],
        },
        {
          icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chart-column h-8 w-8 text-primary" aria-hidden="true"><path d="M3 3v16a2 2 0 0 0 2 2h16"></path><path d="M18 17V9"></path><path d="M13 17V5"></path><path d="M8 17v-3"></path></svg>`,
          title: "Space Utilization Analytics",
          description:
            "Harness unparalleled insights into daily on-site activities to revolutionize office layouts and curtail space wastage.",
          features: [
            "Usage analytics",
            "Capacity optimization",
            "Cost reduction insights",
          ],
        },
        {
          icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-navigation h-8 w-8 text-primary" aria-hidden="true"><polygon points="3 11 22 2 13 21 11 13 3 11"></polygon></svg>`,
          title: "Guided Routing",
          description:
            "Guided routing on maps for easy access to booked seat locations, enhancing navigation efficiency within large office spaces.",
          features: [
            "Turn-by-turn navigation",
            "Optimal path finding",
            "Accessibility routing",
          ],
        },
        {
          icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-smartphone h-8 w-8 text-primary" aria-hidden="true"><rect width="14" height="20" x="5" y="2" rx="2" ry="2"></rect><path d="M12 18h.01"></path></svg>`,
          title: "Mobile-First Platform",
          description:
            "Complete mobile accessibility with QR code scanner for check-in/out, ensuring seamless workspace management from any device.",
          features: ["Mobile booking", "QR scanning", "On-the-go management"],
        },
        {
          icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shield h-8 w-8 text-primary" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path></svg>`,
          title: "Secure Access Control",
          description:
            "Enterprise-grade security with facial recognition-based seat check-in and advanced access management features.",
          features: [
            "Facial recognition",
            "Secure authentication",
            "Access control integration",
          ],
        },
        {
          icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-network h-8 w-8 text-primary" aria-hidden="true"><rect x="16" y="16" width="6" height="6" rx="1"></rect><rect x="2" y="16" width="6" height="6" rx="1"></rect><rect x="9" y="2" width="6" height="6" rx="1"></rect><path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3"></path><path d="M12 12V8"></path></svg>`,
          title: "BMS Integration",
          description:
            "API-based integration with other Building Management Systems for comprehensive facility management and automation.",
          features: [
            "BMS connectivity",
            "System integration",
            "Automated workflows",
          ],
        },
        {
          icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-zap h-8 w-8 text-primary" aria-hidden="true"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>`,
          title: "Predictive Technology",
          description:
            "Advanced space recommendation engine helps employees connect and collaborate while securing optimal workspace locations.",
          features: [
            "AI recommendations",
            "Predictive analytics",
            "Smart matching",
          ],
        },
        {
          icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-award h-8 w-8 text-primary" aria-hidden="true"><path d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526"></path><circle cx="12" cy="8" r="6"></circle></svg>`,
          title: "Cost-Effective Solution",
          description:
            "Unmatched value with significant cost advantage compared to leading market players, offering premium features at competitive pricing.",
          features: [
            "Cost optimization",
            "Premium features",
            "Competitive advantage",
          ],
        },
      ];
      let htmpList = "";
      solutions.forEach((resp) => {
        htmpList += `
          <div data-slots='card'
            class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl hover:-translate-y-2 transition">
            <div data-slot="card-header" class="text-center mb-4">
              <div class="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                ${resp.icon}
              </div>
              <h3 class="text-lg font-semibold">${resp.title}</h3>
            </div>
            <p class="text-gray-600 text-sm mb-4">${resp.description}</p>
             <ul class="space-y-2 text-sm text-gray-600">`;

        resp.features.forEach((innerResp) => {
          htmpList += `<li class="flex items-center">
                <span class="w-1 h-1 bg-blue-600 rounded-full mr-2"></span> ${innerResp} </li>`;
        });
        htmpList += `
            </ul>
            </div>
            `;
      });

      function recursiveCheck(){
        debugger
        let card = document.getElementById("cardData");
        if(card){
            card.innerHTML = htmpList
        }else{
            setTimeout(()=>{
                recursiveCheck();
            }, 10)
        }
      }
      recursiveCheck()
      
  document.addEventListener("DOMContentLoaded", () => {
    debugger
    scrollfn();


  });

  function scrollfn(){
        const backToTopBtn = document.getElementById("backToTop");
        if(backToTopBtn){
        // Show button after scrolling 200px
    window.addEventListener("scroll", () => {
      if (window.scrollY > 200) {
        backToTopBtn.style.display = "block";
      } else {
        backToTopBtn.style.display = "none";
      }
    });

    // Smooth scroll to top
    backToTopBtn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }else{
    setTimeout(()=>{
      scrollfn();
    },20)
  }

  }

      