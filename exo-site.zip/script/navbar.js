  function openMenu() {
      mobileMenu.classList.remove('translate-x-full');
      overlay.classList.remove('pointer-events-none', 'opacity-0');
    }

 
    function closeMenuFunc() {
      mobileMenu.classList.add('translate-x-full');
      overlay.classList.add('pointer-events-none', 'opacity-0');
    }



